package com.codepath.articlesearch
import android.support.annotation.Keep
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Keep
@Serializable
data class  SearchNewResponse(
    @SerialName("response")
    val response: BaseResponse?

)

@Keep
@Serializable
data class BaseResponse(
    @SerialName("docs")
    val docs: List<Article>?
)

@Keep
@Serializable
data class Article(
    @SerialName("name")
    val name: String?,

    @SerialName("calories")
    val calories: Double?,


)//: java.io.Serializable {
    //val mediaImageUrl = "https://www.nytimes.com/${multimedia?.firstOrNull { it.url != null }?.url ?: ""}"
//}

@Keep
@Serializable
data class Name(
    @SerialName("main")
    val name: String
): java.io.Serializable

@Keep
@Serializable
data class Calories(
    @SerialName("original")
    val calories: String? = null
): java.io.Serializable
