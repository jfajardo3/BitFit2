package com.codepath.articlesearch

data class DisplayFit(
    val headline: String?,
    val abstract: Double?
) : java.io.Serializable