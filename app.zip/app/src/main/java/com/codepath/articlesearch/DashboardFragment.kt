package com.codepath.articlesearch

import android.os.Bundle
import android.provider.SyncStateContract.Helpers.update
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.launch
import okhttp3.Dispatcher

class DashboardFragment : Fragment() {
    private lateinit var averageTextView: TextView
    private lateinit var minTextView: TextView
    private lateinit var maxTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        val view = inflater.inflate(R.layout.fragment_dashboard, container, false)

        averageTextView = view.findViewById(R.id.averageTV)
        minTextView = view.findViewById(R.id.minTV)
        maxTextView = view.findViewById(R.id.maxTV)
        val clearButtonView : Button = view.findViewById(R.id.clearBT)

        lifecycleScope.launch {
            (activity?.application as FitApplication).db.fitDao().getAll.collect { databaseList ->
                databaseList.map { entity ->
                    DisplayFit(
                        entity.name,
                        entity.calories
                    )
                }.also { mappedList ->
                    update(mappedList)
                }
            }
        }

        clearButtonView.setOnClickListener {
            lifecycleScope.launch(Dispatcher.IO) {



            }
        }

    }

    private fun update(foods: List<DisplayFit>) {
        if (foods.isEmpty()) {
            averageTextView.text = "No Data"
            minTextView.text = "No Data"
            maxTextView.text = "No Data"

            return
        }

        var min : Double = Double.MAX_VALUE
        var max : Double = Double.MIN_VALUE
        var sum : Double = 0.0

        for (food in foods){
            food.calories?.let {
                
            }
        }
    }

}