package com.codepath.articlesearch;

public class LogFragment {
}
